-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 03 2026 г., 09:55
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `vilams0i_gogol`
--

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--
-- Создание: Мар 01 2026 г., 14:03
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT NULL,
  `available` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `year`, `isbn`, `genre`, `cover_url`, `available`) VALUES
(1, 'Мастер и Маргарита', 'Булгаков', 1967, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/4554655/img_id2110870732930675448.jpeg/orig', 1),
(2, 'Война и мир', 'Толстой', 1869, NULL, NULL, 'https://ir.ozone.ru/s3/multimedia-1-y/7328612434.jpg', 2),
(3, 'Преступление и наказание', 'Достоевский', 1866, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/16321177/2a0000019a4e9ac1c8456b83218e21fb7805/orig', 0),
(4, 'Три товарища', 'Эрих Мария Ремарк', 1936, NULL, NULL, 'https://avatars.mds.yandex.net/i?id=652f54bb47854f766e90cb3b51152f3e_l-10698321-images-thumbs&n=13', 2),
(5, 'Над пропастью во ржи', 'Джером Сэлинджер', 1951, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/16341179/2a0000019a52021f82a43ab661548296c0bc/orig', 1),
(6, 'Портрет Дориана Грея', 'Оскар Уайльд', 1890, NULL, NULL, 'https://ir.ozone.ru/s3/multimedia-o/c600/6425867496.jpg', 3),
(7, 'Сто лет одиночества', 'Габриэль Гарсиа Маркес', 1967, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/11930023/2a0000019091473f124c2fc5cd08f9a70237/orig', 1),
(8, 'Унесенные ветром', 'Маргарет Митчелл', 1936, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/5236458/img_id7848261199740906202.jpeg/orig', 1),
(9, 'Тихий Дон', 'Михаил Шолохов', 1940, NULL, NULL, 'https://ir.ozone.ru/s3/multimedia-8/6664007384.jpg', 1),
(10, 'Братья Карамазовы', 'Фёдор Достоевский', 1880, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/4011308/img_id1033747665466795737.jpeg/orig', 1),
(11, 'Анна Каренина', 'Лев Толстой', 1877, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/5031495/2a00000193428a18b4bb623d311681f028c5/orig', 2),
(12, 'Собачье сердце', 'Михаил Булгаков', 1925, NULL, NULL, 'https://avatars.mds.yandex.net/get-mpic/4119784/img_id5021258211520004717.jpeg/orig', 3),
(13, 'Чайка по имени Джонатан Ливингстон', 'Ричард Бах', 1970, NULL, NULL, 'https://ir.ozone.ru/s3/multimedia-y/6861055858.jpg', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `requests`
--
-- Создание: Мар 01 2026 г., 08:32
-- Последнее обновление: Мар 01 2026 г., 15:48
--

DROP TABLE IF EXISTS `requests`;
CREATE TABLE `requests` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `book_id` int DEFAULT NULL,
  `status` enum('pending','approved','returned') DEFAULT 'pending',
  `issue_date` date DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `requests`
--

INSERT INTO `requests` (`id`, `user_id`, `book_id`, `status`, `issue_date`, `issued_date`, `due_date`, `return_date`) VALUES
(3, 2, 1, 'returned', '2026-03-01', '2026-03-01', '2026-03-06', '2026-03-01'),
(4, 2, 1, '', '2026-03-01', NULL, NULL, NULL),
(5, 1, 2, '', '2026-03-01', NULL, NULL, NULL),
(6, 1, 3, '', '2026-03-01', NULL, NULL, NULL),
(7, 1, 2, 'returned', '2026-03-01', '2026-03-01', '2026-03-12', '2026-03-01'),
(8, 2, 2, 'returned', '2026-03-01', '2026-03-01', '2026-03-11', '2026-03-01'),
(9, 2, 8, '', '2026-03-01', NULL, NULL, NULL),
(10, 4, 1, 'returned', '2026-03-01', '2026-03-01', '2026-03-05', '2026-03-01'),
(11, 4, 2, 'returned', '2026-03-01', '2026-03-01', '2026-03-09', '2026-03-01'),
(12, 4, 11, 'returned', '2026-03-01', '2026-03-01', '2026-03-15', '2026-03-01'),
(13, 4, 2, 'returned', '2026-03-01', '2026-03-01', '2026-03-22', '2026-03-01'),
(14, 4, 5, 'returned', '2026-03-01', '2026-03-01', '2026-03-15', '2026-03-01'),
(15, 2, 1, 'returned', '2026-03-01', '2026-03-01', '2026-03-15', '2026-03-01'),
(16, 4, 2, 'returned', '2026-03-01', '2026-03-01', '2026-03-11', '2026-03-01'),
(17, 4, 3, 'returned', '2026-03-01', '2026-03-01', '2026-03-09', '2026-03-01'),
(18, 4, 11, 'returned', '2026-03-01', '2026-03-01', '2026-03-15', '2026-03-01'),
(19, 4, 2, 'returned', '2026-03-01', '2026-03-01', '2026-03-02', '2026-03-01'),
(20, 4, 13, 'approved', '2026-03-01', '2026-03-01', '2026-03-03', NULL),
(21, 4, 3, 'approved', '2026-03-01', '2026-03-01', '2026-03-15', NULL),
(22, 2, 8, 'approved', '2026-03-01', '2026-03-01', '2026-03-15', NULL),
(23, 2, 10, 'approved', '2026-03-01', '2026-03-01', '2026-03-02', NULL),
(24, 5, 9, 'pending', '2026-03-01', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Фев 28 2026 г., 21:55
-- Последнее обновление: Мар 01 2026 г., 14:22
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('reader','admin') DEFAULT 'reader'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'Admin', 'admin@mail.ru', '$2a$12$CVrhO9dpu1H/cdSG4zeUb.dyS5HtC7/bbzSp0gr1Z8unGPHegarwS', 'admin'),
(2, 'Кирилл', 'vilamskirill@gmail.com', '$2y$10$h91QAE0.Pr/GIYRj4BREtuMlXKQ9tD2sC7zagg3l4AeljXew1XIAa', 'reader'),
(4, 'Антон', 'anton@mail.ru', '$2y$10$qRMadoSBkhkTfpX2Op5itelg60R8lQ0HJ6zrnw7hAgQGPrdvaA0Ei', 'reader'),
(5, 'Анастасия', 'anastas@mail.ru', '$2y$10$3t0C8AjtXCctEugKRFXkBeX92Slnsc83Cejr4ttYtbc5VfGa2rAxu', 'reader');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `books`
--
ALTER TABLE `books`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
