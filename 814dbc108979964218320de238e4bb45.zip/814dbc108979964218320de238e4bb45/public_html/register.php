<?php
require_once 'config/db.php';

$error = '';

if ($_POST) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Проверка, не занят ли email
    $check = $conn->query("SELECT id FROM users WHERE email = '$email'");
    if ($check->num_rows > 0) {
        $error = 'Пользователь с таким email уже зарегистрирован.';
    } else {
        // Хешируем пароль и добавляем пользователя
        $pass = password_hash($password, PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$pass', 'reader')");
        
        // Получаем ID нового пользователя
        $user_id = $conn->insert_id;
        
        // Автоматический вход
        $_SESSION['id'] = $user_id;
        $_SESSION['role'] = 'reader';
        
        header("Location: index.php");
        exit;
    }
}

include 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="card shadow-lg border-0 rounded-4">
            <div class="card-body p-5">
                <h2 class="text-center mb-4">Регистрация</h2>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Имя</label>
                        <input type="text" class="form-control form-control-lg" id="name" name="name" 
                               placeholder="Иван Петров" required
                               value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control form-control-lg" id="email" name="email" 
                               placeholder="example@mail.ru" required
                               value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                    </div>
                    <div class="mb-4">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control form-control-lg" id="password" name="password" 
                               placeholder="••••••••" required>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Зарегистрироваться</button>
                    </div>
                </form>

                <p class="text-center mt-4 mb-0">
                    Уже есть аккаунт? <a href="login.php" class="text-decoration-none">Войти</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>