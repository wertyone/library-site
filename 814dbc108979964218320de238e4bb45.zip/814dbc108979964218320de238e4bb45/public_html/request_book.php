<?php
include 'includes/header.php';
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$book_id = (int)$_GET['id'];
$user_id = $_SESSION['id'];

// Проверяем, нет ли уже активной заявки
$check = $conn->prepare("SELECT id FROM requests WHERE user_id = ? AND book_id = ? AND status IN ('pending','approved')");
$check->bind_param("ii", $user_id, $book_id);
$check->execute();
$result = $check->get_result();
if ($result->num_rows == 0) {
    $insert = $conn->prepare("INSERT INTO requests (user_id, book_id, status, issue_date) VALUES (?, ?, 'pending', CURDATE())");
    $insert->bind_param("ii", $user_id, $book_id);
    $insert->execute();
}
header("Location: my_books.php");
exit;