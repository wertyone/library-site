<?php
include 'includes/header.php';
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}
$id = $_SESSION['id'];

// Получаем книги пользователя с данными о просрочке
$stmt = $conn->prepare("
    SELECT books.title, books.author, books.cover_url, requests.status, requests.issue_date, requests.due_date
    FROM requests 
    JOIN books ON requests.book_id = books.id
    WHERE requests.user_id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

// Подсчитываем просроченные и собираем книги
$overdueCount = 0;
$books = [];
while ($row = $res->fetch_assoc()) {
    $overdue = ($row['status'] == 'approved' && $row['due_date'] && $row['due_date'] < date('Y-m-d'));
    if ($overdue) $overdueCount++;
    $row['overdue'] = $overdue;
    $books[] = $row;
}
?>
<div class="row mb-4 align-items-center">
    <div class="col">
        <h2>Мои книги</h2>
    </div>
    <?php if ($overdueCount > 0): ?>
    <div class="col-auto">
        <span class="badge bg-danger fs-6"><?= $overdueCount ?> просрочено</span>
    </div>
    <?php endif; ?>
</div>

<div class="row">
    <?php if (empty($books)): ?>
        <div class="col">
            <p class="text-muted">У вас пока нет книг.</p>
        </div>
    <?php else: ?>
        <?php foreach ($books as $book): ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100 <?= $book['overdue'] ? 'border-danger' : '' ?>">
                    <div class="row g-0 h-100">
                        <div class="col-md-4">
                            <img src="<?= !empty($book['cover_url']) ? htmlspecialchars($book['cover_url']) : '/uploads/default-book.jpg' ?>" 
                                 class="img-fluid rounded-start h-100" style="object-fit: cover;" 
                                 alt="<?= htmlspecialchars($book['title']) ?>">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($book['title']) ?></h5>
                                <p class="card-text text-muted"><?= htmlspecialchars($book['author']) ?></p>
                                <p class="card-text">
                                    <small class="text-muted">Взята: <?= date('d.m.Y', strtotime($book['issue_date'])) ?></small><br>
                                    <?php if ($book['due_date']): ?>
                                        <small class="<?= $book['overdue'] ? 'text-danger fw-bold' : 'text-muted' ?>">
                                            Вернуть до: <?= date('d.m.Y', strtotime($book['due_date'])) ?>
                                            <?php if ($book['overdue']): ?> (просрочена) <?php endif; ?>
                                        </small>
                                    <?php endif; ?>
                                </p>
                                <?php if ($book['status'] == 'pending'): ?>
                                    <span class="badge bg-warning">Ожидает подтверждения</span>
                                <?php elseif ($book['status'] == 'returned'): ?>
                                    <span class="badge bg-secondary">Возвращена</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>