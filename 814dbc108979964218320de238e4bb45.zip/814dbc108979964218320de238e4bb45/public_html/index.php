<?php include 'includes/header.php'; ?>

<style>
    .book-card {
        cursor: pointer;
        transition: transform 0.2s;
    }
    .book-card:hover {
        transform: translateY(-5px);
    }
</style>

<h2>Каталог книг</h2>
<div class="row">
<?php
$result = $conn->query("SELECT * FROM books");
while($book = $result->fetch_assoc()):
    // Данные для data-атрибутов (экранируем)
    $title = htmlspecialchars($book['title']);
    $author = htmlspecialchars($book['author']);
    $year = (int)$book['year'];
    $isbn = htmlspecialchars($book['isbn'] ?? '');
    $genre = htmlspecialchars($book['genre'] ?? '');
    $available = (int)$book['available'];
    $cover = !empty($book['cover_url']) ? htmlspecialchars($book['cover_url']) : '/uploads/default-book.jpg';
?>
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm book-card"
             data-id="<?= $book['id'] ?>"
             data-title="<?= $title ?>"
             data-author="<?= $author ?>"
             data-year="<?= $year ?>"
             data-isbn="<?= $isbn ?>"
             data-genre="<?= $genre ?>"
             data-available="<?= $available ?>"
             data-cover="<?= $cover ?>">
            <img src="<?= $cover ?>" class="card-img-top" alt="<?= $title ?>">
            <div class="card-body">
                <h5 class="card-title"><?= $title ?></h5>
                <p class="card-text text-muted"><?= $author ?></p>
            </div>
        </div>
    </div>
<?php endwhile; ?>
</div>

<!-- Модальное окно для детального просмотра книги -->
<div class="modal fade" id="bookModal" tabindex="-1" aria-labelledby="bookModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bookModalLabel">Информация о книге</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="text-center mb-3">
          <img src="" id="modal-cover" class="img-fluid" style="max-height:200px;" alt="Обложка">
        </div>
        <h4 id="modal-title"></h4>
        <p id="modal-author" class="text-muted"></p>
        <p id="modal-genre"></p>
        <p id="modal-isbn"></p>
        <p id="modal-status" class="fw-bold"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
        <a href="#" id="modal-take-btn" class="btn btn-primary">Взять книгу</a>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Инициализируем модальное окно Bootstrap
    const bookModal = new bootstrap.Modal(document.getElementById('bookModal'));
    const modalCover = document.getElementById('modal-cover');
    const modalTitle = document.getElementById('modal-title');
    const modalAuthor = document.getElementById('modal-author');
    const modalGenre = document.getElementById('modal-genre');
    const modalIsbn = document.getElementById('modal-isbn');
    const modalStatus = document.getElementById('modal-status');
    const modalTakeBtn = document.getElementById('modal-take-btn');

    // Обработчик клика по карточке книги
    document.querySelectorAll('.book-card').forEach(card => {
        card.addEventListener('click', function() {
            // Читаем data-атрибуты
            const id = this.dataset.id;
            const title = this.dataset.title;
            const author = this.dataset.author;
            const year = this.dataset.year;
            const isbn = this.dataset.isbn;
            const genre = this.dataset.genre;
            const available = parseInt(this.dataset.available);
            const cover = this.dataset.cover;

            // Заполняем модальное окно
            modalCover.src = cover;
            modalTitle.textContent = title;
            modalAuthor.textContent = author + (year ? ` (${year})` : '');
            modalGenre.textContent = genre ? `Жанр: ${genre}` : '';
            modalIsbn.textContent = isbn ? `ISBN: ${isbn}` : '';

            if (available > 0) {
                modalStatus.textContent = 'Доступна';
                modalStatus.className = 'fw-bold text-success';
                modalTakeBtn.style.display = 'inline-block';
                modalTakeBtn.href = 'request_book.php?id=' + id;
            } else {
                modalStatus.textContent = 'Выдана';
                modalStatus.className = 'fw-bold text-danger';
                modalTakeBtn.style.display = 'none';
            }

            // Показываем модальное окно
            bookModal.show();
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>