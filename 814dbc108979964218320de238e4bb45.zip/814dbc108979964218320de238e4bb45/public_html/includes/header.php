<?php
require_once __DIR__ . '/../config/db.php';

// Подсчёт просроченных книг для текущего пользователя
$overdueCount = 0;
$adminOverdueCount = 0;

if (isset($_SESSION['id'])) {
    $userId = (int)$_SESSION['id'];
    $result = $conn->query("SELECT COUNT(*) as cnt FROM requests WHERE user_id = $userId AND status = 'approved' AND due_date < CURDATE()");
    if ($result) {
        $row = $result->fetch_assoc();
        $overdueCount = $row['cnt'];
    }

    if ($_SESSION['role'] == 'admin') {
        $resultAdmin = $conn->query("SELECT COUNT(*) as cnt FROM requests WHERE status = 'approved' AND due_date < CURDATE()");
        if ($resultAdmin) {
            $rowAdmin = $resultAdmin->fetch_assoc();
            $adminOverdueCount = $rowAdmin['cnt'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library 2.0</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark main-nav">
<div class="container">
<a class="navbar-brand fw-bold" href="/index.php">📚 LibraryIS</a>

<div>
<?php if(isset($_SESSION['id'])): ?>
    <a href="/index.php" class="btn btn-outline-light btn-sm">Каталог</a>
    <a href="/search.php" class="btn btn-light btn-sm">Поиск</a>
    
    <!-- Мои книги с бейджем просрочки -->
    <a href="/my_books.php" class="btn btn-warning btn-sm position-relative">
        Мои книги
        <?php if ($overdueCount > 0): ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                <?= $overdueCount ?>
                <span class="visually-hidden">просроченных книг</span>
            </span>
        <?php endif; ?>
    </a>

    <?php if($_SESSION['role']=='admin'): ?>
        <a href="/admin/dashboard.php" class="btn btn-danger btn-sm position-relative">
            Заявки
            <?php if ($adminOverdueCount > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark">
                    <?= $adminOverdueCount ?>
                    <span class="visually-hidden">просроченных книг всего</span>
                </span>
            <?php endif; ?>
        </a>
        <a href="/admin/books.php" class="btn btn-info btn-sm">Книги</a>
    <?php endif; ?>

    <a href="/logout.php" class="btn btn-outline-light btn-sm">Выход</a>

<?php else: ?>
    <a href="/index.php" class="btn btn-outline-light btn-sm">Каталог</a>
    <a href="/login.php" class="btn btn-success btn-sm">Вход</a>
    <a href="/register.php" class="btn btn-primary btn-sm">Регистрация</a>
<?php endif; ?>
</div>
</div>
</nav>

<div class="container mt-4">