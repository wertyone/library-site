<?php
session_start();
$host = "localhost";
$db = "vilams0i_gogol";
$user = "vilams0i_gogol";
$pass = "Fik517946";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
$conn->set_charset("utf8");
?>