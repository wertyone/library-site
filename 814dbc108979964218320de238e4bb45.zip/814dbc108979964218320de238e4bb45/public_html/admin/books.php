<?php
include '../includes/header.php';
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') die("Нет доступа");

// Обработка добавления/редактирования/удаления
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $title = $conn->real_escape_string($_POST['title']);
        $author = $conn->real_escape_string($_POST['author']);
        $year = (int)$_POST['year'];
        $available = (int)$_POST['available'];
        $cover_url = $conn->real_escape_string($_POST['cover_url']);
        $conn->query("INSERT INTO books (title, author, year, available, cover_url) VALUES ('$title', '$author', $year, $available, '$cover_url')");
    } elseif (isset($_POST['edit'])) {
        $id = (int)$_POST['id'];
        $title = $conn->real_escape_string($_POST['title']);
        $author = $conn->real_escape_string($_POST['author']);
        $year = (int)$_POST['year'];
        $available = (int)$_POST['available'];
        $cover_url = $conn->real_escape_string($_POST['cover_url']);
        $conn->query("UPDATE books SET title='$title', author='$author', year=$year, available=$available, cover_url='$cover_url' WHERE id=$id");
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $check = $conn->query("SELECT id FROM requests WHERE book_id=$id LIMIT 1");
        if ($check->num_rows == 0) {
            $conn->query("DELETE FROM books WHERE id=$id");
        } else {
            $error = "Нельзя удалить книгу, есть связанные заявки";
        }
    }
    header("Location: books.php");
    exit;
}

$books = $conn->query("SELECT * FROM books ORDER BY id");
?>
<h2>Управление книгами</h2>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<!-- Форма добавления новой книги -->
<div class="card mb-4 p-3">
    <h5>Добавить книгу</h5>
    <form method="post">
        <div class="row g-2">
            <div class="col-md-3">
                <input type="text" name="title" class="form-control" placeholder="Название" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="author" class="form-control" placeholder="Автор" required>
            </div>
            <div class="col-md-1">
                <input type="number" name="year" class="form-control" placeholder="Год" required>
            </div>
            <div class="col-md-1">
                <input type="number" name="available" class="form-control" placeholder="Доступно" value="1" min="0" required>
            </div>
            <div class="col-md-3">
                <input type="url" name="cover_url" class="form-control" placeholder="Ссылка на обложку">
            </div>
            <div class="col-md-1">
                <button type="submit" name="add" class="btn btn-primary">Добавить</button>
            </div>
        </div>
    </form>
</div>

<!-- Таблица книг -->
<table class="table table-bordered table-striped">
<thead>
    <tr>
        <th>ID</th>
        <th>Обложка</th>
        <th>Название</th>
        <th>Автор</th>
        <th>Год</th>
        <th>Доступно</th>
        <th>Действия</th>
    </tr>
</thead>
<tbody>
<?php while ($book = $books->fetch_assoc()): ?>
<tr>
    <td><?= $book['id'] ?></td>
    <td>
        <?php if (!empty($book['cover_url'])): ?>
            <img src="<?= htmlspecialchars($book['cover_url']) ?>" style="max-width:60px; max-height:80px;">
        <?php else: ?>
            <span class="text-muted">нет</span>
        <?php endif; ?>
    </td>
    <td><?= htmlspecialchars($book['title']) ?></td>
    <td><?= htmlspecialchars($book['author']) ?></td>
    <td><?= $book['year'] ?></td>
    <td><?= $book['available'] ?></td>
    <td>
        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $book['id'] ?>">✎</button>
        <form method="post" style="display:inline;" onsubmit="return confirm('Удалить книгу?');">
            <input type="hidden" name="id" value="<?= $book['id'] ?>">
            <button type="submit" name="delete" class="btn btn-sm btn-danger">✕</button>
        </form>
    </td>
</tr>

<!-- Модальное окно редактирования -->
<div class="modal fade" id="editModal<?= $book['id'] ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Редактировать книгу</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="post">
                    <input type="hidden" name="id" value="<?= $book['id'] ?>">
                    <div class="mb-2">
                        <label>Название</label>
                        <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($book['title']) ?>" required>
                    </div>
                    <div class="mb-2">
                        <label>Автор</label>
                        <input type="text" name="author" class="form-control" value="<?= htmlspecialchars($book['author']) ?>" required>
                    </div>
                    <div class="mb-2">
                        <label>Год</label>
                        <input type="number" name="year" class="form-control" value="<?= $book['year'] ?>" required>
                    </div>
                    <div class="mb-2">
                        <label>Доступно экземпляров</label>
                        <input type="number" name="available" class="form-control" value="<?= $book['available'] ?>" min="0" required>
                    </div>
                    <div class="mb-2">
                        <label>Ссылка на обложку</label>
                        <input type="url" name="cover_url" class="form-control" value="<?= htmlspecialchars($book['cover_url']) ?>">
                    </div>
                    <button type="submit" name="edit" class="btn btn-primary">Сохранить</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endwhile; ?>
</tbody>
</table>

<?php include '../includes/footer.php'; ?>