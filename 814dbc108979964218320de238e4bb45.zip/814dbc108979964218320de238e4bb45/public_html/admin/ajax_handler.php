<?php
// admin/ajax_handler.php
require_once '../config/db.php';

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Доступ запрещён']);
    exit;
}

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if (in_array($action, ['approve', 'reject', 'extend', 'return'])) {
        $request_id = (int)$_POST['request_id'];
    }

    if ($action === 'approve') {
        $days = (int)$_POST['loan_days'];
        $stmt = $conn->prepare("SELECT book_id FROM requests WHERE id = ?");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $book = $stmt->get_result()->fetch_assoc();
        if ($book) {
            $book_id = $book['book_id'];
            $update = $conn->prepare("UPDATE requests SET status = 'approved', issued_date = CURDATE(), due_date = DATE_ADD(CURDATE(), INTERVAL ? DAY) WHERE id = ?");
            $update->bind_param("ii", $days, $request_id);
            if ($update->execute()) {
                $conn->query("UPDATE books SET available = available - 1 WHERE id = $book_id AND available > 0");
                $response['success'] = true;
                $response['new_status'] = 'approved';
                $response['issued_date'] = date('Y-m-d');
                $response['due_date'] = date('Y-m-d', strtotime("+$days days"));
            }
        }
    } elseif ($action === 'reject') {
        $update = $conn->prepare("UPDATE requests SET status = 'rejected' WHERE id = ?");
        $update->bind_param("i", $request_id);
        if ($update->execute()) {
            $response['success'] = true;
            $response['new_status'] = 'rejected';
        }
    } elseif ($action === 'extend') {
        $extra_days = (int)$_POST['extra_days'];
        $update = $conn->prepare("UPDATE requests SET due_date = DATE_ADD(due_date, INTERVAL ? DAY) WHERE id = ? AND status = 'approved'");
        $update->bind_param("ii", $extra_days, $request_id);
        if ($update->execute() && $update->affected_rows > 0) {
            $stmt = $conn->prepare("SELECT due_date FROM requests WHERE id = ?");
            $stmt->bind_param("i", $request_id);
            $stmt->execute();
            $due = $stmt->get_result()->fetch_assoc();
            $response['success'] = true;
            $response['due_date'] = $due['due_date'];
        }
    } elseif ($action === 'return') {
        $stmt = $conn->prepare("SELECT book_id FROM requests WHERE id = ? AND status = 'approved'");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $book = $stmt->get_result()->fetch_assoc();
        if ($book) {
            $book_id = $book['book_id'];
            $update = $conn->prepare("UPDATE requests SET status = 'returned', return_date = CURDATE() WHERE id = ?");
            $update->bind_param("i", $request_id);
            if ($update->execute()) {
                $conn->query("UPDATE books SET available = available + 1 WHERE id = $book_id");
                $response['success'] = true;
                $response['new_status'] = 'returned';
                $response['return_date'] = date('Y-m-d');
            }
        }
    } elseif ($action === 'issue') {
        $reader_id = (int)$_POST['reader_id'];
        $book_id = (int)$_POST['book_id'];
        $days = (int)$_POST['loan_days'];

        $checkBook = $conn->query("SELECT available FROM books WHERE id = $book_id AND available > 0");
        if ($checkBook->num_rows === 0) {
            $response['error'] = 'Книга недоступна';
            echo json_encode($response);
            exit;
        }

        $insert = $conn->prepare("INSERT INTO requests (user_id, book_id, status, issue_date, issued_date, due_date) VALUES (?, ?, 'approved', CURDATE(), CURDATE(), DATE_ADD(CURDATE(), INTERVAL ? DAY))");
        $insert->bind_param("iii", $reader_id, $book_id, $days);
        if ($insert->execute()) {
            $request_id = $insert->insert_id;
            $conn->query("UPDATE books SET available = available - 1 WHERE id = $book_id");
            $response['success'] = true;
            $response['request_id'] = $request_id;
            $response['due_date'] = date('Y-m-d', strtotime("+$days days"));
        } else {
            $response['error'] = 'Ошибка при создании заявки';
        }
    }

    echo json_encode($response);
    exit;
}