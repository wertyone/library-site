<?php
include '../includes/header.php';
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') die("Нет доступа");

// Получаем общее количество книг
$totalBooks = $conn->query("SELECT COUNT(*) as cnt FROM books")->fetch_assoc()['cnt'];

// Получаем всех читателей (кроме администраторов)
$readers = $conn->query("
    SELECT u.id, u.name, u.email 
    FROM users u 
    WHERE u.role = 'reader' OR u.role IS NULL
");

// Для каждого читателя получим его активные (approved) и запрошенные (pending) книги
$readersData = [];
while ($reader = $readers->fetch_assoc()) {
    $readerId = $reader['id'];

    // Активные книги (выданные)
    $approvedBooks = $conn->query("
        SELECT r.id as request_id, b.id as book_id, b.title, b.cover_url, r.due_date 
        FROM requests r
        JOIN books b ON r.book_id = b.id
        WHERE r.user_id = $readerId AND r.status = 'approved'
    ");
    $approved = [];
    while ($book = $approvedBooks->fetch_assoc()) {
        $due = $book['due_date'];
        $today = date('Y-m-d');
        $overdue = ($due < $today);
        $book['overdue'] = $overdue;
        $book['days_overdue'] = $overdue ? (new DateTime($due))->diff(new DateTime($today))->days : 0;
        $approved[] = $book;
    }

    // Запрошенные книги (ожидающие одобрения)
    $pendingBooks = $conn->query("
        SELECT r.id as request_id, b.id as book_id, b.title, b.author, b.year, b.cover_url
        FROM requests r
        JOIN books b ON r.book_id = b.id
        WHERE r.user_id = $readerId AND r.status = 'pending'
    ");
    $pending = [];
    while ($book = $pendingBooks->fetch_assoc()) {
        $pending[] = $book;
    }

    $readersData[] = [
        'id' => $reader['id'],
        'name' => $reader['name'],
        'email' => $reader['email'],
        'approved_books' => $approved,
        'pending_books' => $pending
    ];
}

// Получаем все доступные книги (available > 0)
$availableBooks = $conn->query("SELECT id, title, author, year, cover_url FROM books WHERE available > 0 ORDER BY title");
?>
<style>
    .reader-card {
        border: none;
        border-radius: 20px;
        background: white;
        box-shadow: 0 8px 20px rgba(0,0,0,0.05);
        margin-bottom: 20px;
        transition: all 0.2s;
        cursor: pointer;
    }
    .reader-card.selected {
        border: 2px solid #0d6efd;
        box-shadow: 0 8px 25px rgba(13,110,253,0.2);
    }
    .reader-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.1);
    }
    .reader-avatar {
        width: 50px;
        height: 50px;
        border-radius: 15px;
        background: #1e2a38;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 1.2rem;
    }
    .book-item {
        background: #f8f9fa;
        border-radius: 12px;
        padding: 10px 15px;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .book-item.overdue {
        border-left: 4px solid #dc3545;
    }
    .book-item.pending {
        border-left: 4px solid #ffc107;
    }
    .badge-overdue {
        background: #dc3545;
        color: white;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 0.75rem;
    }
    .stats-card {
        background: linear-gradient(135deg, #1e2a38 0%, #2c3e50 100%);
        color: white;
        border-radius: 25px;
        padding: 25px;
        margin-bottom: 30px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    }
    .available-book {
        background: white;
        border-radius: 12px;
        padding: 10px;
        margin-bottom: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        display: flex;
        align-items: center;
        transition: background 0.2s;
    }
    .available-book:hover {
        background: #f8f9fa;
    }
    .available-book img {
        width: 50px;
        height: 50px;
        border-radius: 8px;
        object-fit: cover;
        margin-right: 15px;
    }
    #available-books-list {
        max-height: 500px;
        overflow-y: auto;
        padding-right: 10px;
    }
    .loan-days-input {
        width: 70px;
        display: inline-block;
    }
    .book-item img {
        width: 40px;
        height: 40px;
        border-radius: 6px;
        object-fit: cover;
        margin-right: 12px;
    }
</style>

<div class="stats-card">
    <div class="row align-items-center">
        <div class="col-auto">
            <h3 class="display-4 mb-0"><?= $totalBooks ?></h3>
        </div>
        <div class="col">
            <h5 class="mb-0">Всего книг</h5>
            <p class="text-white-50 mb-0">Управление читателями: выдавайте, принимайте и продлевайте</p>
        </div>
    </div>
</div>

<div class="row">
    <!-- Левая колонка: список читателей -->
    <div class="col-lg-5">
        <h5 class="mb-3">Читатели</h5>
        <div id="readers-list">
            <?php foreach ($readersData as $reader): 
                $initials = mb_substr($reader['name'], 0, 2, 'utf-8');
            ?>
            <div class="reader-card p-3" data-reader-id="<?= $reader['id'] ?>" data-reader-name="<?= htmlspecialchars($reader['name']) ?>">
                <div class="d-flex">
                    <div class="reader-avatar me-3"><?= $initials ?></div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1"><?= htmlspecialchars($reader['name']) ?></h6>
                        <small class="text-secondary">Билет №<?= $reader['id'] ?></small>
                    </div>
                </div>

                <!-- БЛОК ЗАПРОШЕННЫХ КНИГ (PENDING) -->
                <?php if (!empty($reader['pending_books'])): ?>
                    <div class="mt-3">
                        <small class="text-uppercase text-warning fw-bold">Запрошенные книги</small>
                        <?php foreach ($reader['pending_books'] as $book): ?>
                            <div class="book-item pending d-flex align-items-center" data-request-id="<?= $book['request_id'] ?>">
                                <img src="<?= !empty($book['cover_url']) ? htmlspecialchars($book['cover_url']) : 'https://picsum.photos/seed/' . $book['book_id'] . '/40/40' ?>" alt="">
                                <div class="flex-grow-1">
                                    <div class="fw-bold"><?= htmlspecialchars($book['title']) ?></div>
                                    <small class="text-secondary"><?= htmlspecialchars($book['author']) ?> (<?= $book['year'] ?>)</small>
                                </div>
                                <div class="btn-group btn-group-sm">
                                    <input type="number" class="form-control form-control-sm loan-days-input" value="14" min="1" max="365">
                                    <button class="btn btn-sm btn-success btn-approve-pending">Одобрить</button>
                                    <button class="btn btn-sm btn-danger btn-reject-pending">Отклонить</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- БЛОК АКТИВНЫХ КНИГ (APPROVED) -->
                <?php if (!empty($reader['approved_books'])): ?>
                    <div class="mt-3">
                        <small class="text-uppercase text-success fw-bold">Активные книги</small>
                        <?php foreach ($reader['approved_books'] as $book): ?>
                            <div class="book-item d-flex align-items-center <?= $book['overdue'] ? 'overdue' : '' ?>" data-request-id="<?= $book['request_id'] ?>">
                                <img src="<?= !empty($book['cover_url']) ? htmlspecialchars($book['cover_url']) : 'https://picsum.photos/seed/' . $book['book_id'] . '/40/40' ?>" alt="">
                                <div class="flex-grow-1">
                                    <div class="fw-bold"><?= htmlspecialchars($book['title']) ?></div>
                                    <small class="text-secondary">
                                        До <?= date('d.m.Y', strtotime($book['due_date'])) ?>
                                        <?php if ($book['overdue']): ?>
                                            <span class="badge-overdue ms-2">Просрочено <?= $book['days_overdue'] ?> дн.</span>
                                        <?php endif; ?>
                                    </small>
                                </div>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-warning btn-extend" title="Продлить">↻</button>
                                    <button class="btn btn-outline-primary btn-return" title="Принять">✓</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Правая колонка: выдача книг для выбранного читателя -->
    <div class="col-lg-7">
        <div class="card shadow-sm border-0 rounded-4 p-4">
            <h5 id="selected-reader-title">Выдать книгу: <span class="fw-bold">выберите читателя</span></h5>
            <hr>
            <div id="available-books-list">
                <?php if ($availableBooks->num_rows == 0): ?>
                    <p class="text-muted">Нет доступных книг для выдачи</p>
                <?php else: ?>
                    <?php while ($book = $availableBooks->fetch_assoc()): ?>
                        <div class="available-book" data-book-id="<?= $book['id'] ?>">
                            <img src="<?= !empty($book['cover_url']) ? htmlspecialchars($book['cover_url']) : 'https://picsum.photos/seed/' . $book['id'] . '/50/50' ?>" alt="">
                            <div class="flex-grow-1">
                                <strong><?= htmlspecialchars($book['title']) ?></strong><br>
                                <small class="text-secondary"><?= htmlspecialchars($book['author']) ?> (<?= $book['year'] ?>)</small>
                            </div>
                            <button class="btn btn-sm btn-primary btn-issue" data-book-id="<?= $book['id'] ?>" data-book-title="<?= htmlspecialchars($book['title']) ?>">Выдать</button>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let selectedReaderId = null;
    const readersList = document.getElementById('readers-list');
    const selectedReaderTitle = document.getElementById('selected-reader-title');
    const availableBooksList = document.getElementById('available-books-list');

    // Выбор читателя
    readersList.addEventListener('click', function(e) {
        const card = e.target.closest('.reader-card');
        if (!card) return;
        document.querySelectorAll('.reader-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        selectedReaderId = card.dataset.readerId;
        const readerName = card.dataset.readerName;
        selectedReaderTitle.innerHTML = `Выдать книгу: <span class="fw-bold">${readerName}</span>`;
    });

    // Функция отправки AJAX
    async function sendAction(action, data) {
        const formData = new FormData();
        formData.append('action', action);
        for (let key in data) {
            formData.append(key, data[key]);
        }
        const response = await fetch('ajax_handler.php', {
            method: 'POST',
            body: formData
        });
        return await response.json();
    }

    // Обработка выдачи книги (issue)
    availableBooksList.addEventListener('click', async function(e) {
        const btn = e.target.closest('.btn-issue');
        if (!btn) return;
        if (!selectedReaderId) {
            alert('Сначала выберите читателя');
            return;
        }
        const bookId = btn.dataset.bookId;
        const bookTitle = btn.dataset.bookTitle;
        const loanDays = prompt('Срок выдачи (дней):', '14');
        if (!loanDays) return;

        const result = await sendAction('issue', {
            reader_id: selectedReaderId,
            book_id: bookId,
            loan_days: loanDays
        });
        if (result.success) {
            location.reload(); // просто перезагружаем страницу для простоты
        } else {
            alert('Ошибка при выдаче: ' + (result.error || 'неизвестная ошибка'));
        }
    });

    // Обработка кнопок в левой колонке (одобрение, отклонение, продление, возврат)
    readersList.addEventListener('click', async function(e) {
        const target = e.target;
        const bookItem = target.closest('.book-item');
        if (!bookItem) return;
        const requestId = bookItem.dataset.requestId;

        // Одобрение запрошенной книги
        if (target.closest('.btn-approve-pending')) {
            const loanDaysInput = bookItem.querySelector('.loan-days-input');
            const loanDays = loanDaysInput ? loanDaysInput.value : 14;
            const result = await sendAction('approve', {
                request_id: requestId,
                loan_days: loanDays
            });
            if (result.success) {
                location.reload();
            } else {
                alert('Ошибка при одобрении');
            }
        }
        // Отклонение запрошенной книги
        else if (target.closest('.btn-reject-pending')) {
            const result = await sendAction('reject', { request_id: requestId });
            if (result.success) {
                location.reload();
            } else {
                alert('Ошибка при отклонении');
            }
        }
        // Продление активной книги
        else if (target.closest('.btn-extend')) {
            const extraDays = prompt('На сколько дней продлить?', '7');
            if (!extraDays) return;
            const result = await sendAction('extend', {
                request_id: requestId,
                extra_days: extraDays
            });
            if (result.success) {
                location.reload();
            } else {
                alert('Ошибка при продлении');
            }
        }
        // Возврат активной книги
        else if (target.closest('.btn-return')) {
            const result = await sendAction('return', { request_id: requestId });
            if (result.success) {
                location.reload();
            } else {
                alert('Ошибка при приёме');
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>