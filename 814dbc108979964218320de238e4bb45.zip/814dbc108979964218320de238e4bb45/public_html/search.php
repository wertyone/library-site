<?php include 'includes/header.php'; ?>

<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h2 class="card-title text-center mb-4">Расширенный поиск</h2>
                <p class="text-muted text-center mb-4">Найдите нужную книгу по различным критериям</p>

                <form method="GET" action="search.php">
                    <div class="mb-3">
                        <label for="title" class="form-label">Название книги</label>
                        <input type="text" class="form-control" id="title" name="title" 
                               placeholder="Например: 1984" 
                               value="<?= isset($_GET['title']) ? htmlspecialchars($_GET['title']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label for="isbn" class="form-label">ISBN</label>
                        <input type="text" class="form-control" id="isbn" name="isbn" 
                               placeholder="978-5-17-098825-6" 
                               value="<?= isset($_GET['isbn']) ? htmlspecialchars($_GET['isbn']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Автор</label>
                        <input type="text" class="form-control" id="author" name="author" 
                               placeholder="Например: Оруэлл" 
                               value="<?= isset($_GET['author']) ? htmlspecialchars($_GET['author']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label for="genre" class="form-label">Жанр</label>
                        <input type="text" class="form-control" id="genre" name="genre" 
                               placeholder="Например: Фэнтези" 
                               value="<?= isset($_GET['genre']) ? htmlspecialchars($_GET['genre']) : '' ?>">
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Найти книги</button>
                    </div>
                </form>
            </div>
        </div>

        <?php
        // Обработка поиска
        if (isset($_GET['title']) || isset($_GET['isbn']) || isset($_GET['author']) || isset($_GET['genre'])):
            // Безопасная подготовка значений (экранирование)
            $title = isset($_GET['title']) ? '%' . $conn->real_escape_string($_GET['title']) . '%' : '%';
            $isbn = isset($_GET['isbn']) ? '%' . $conn->real_escape_string($_GET['isbn']) . '%' : '%';
            $author = isset($_GET['author']) ? '%' . $conn->real_escape_string($_GET['author']) . '%' : '%';
            $genre = isset($_GET['genre']) ? '%' . $conn->real_escape_string($_GET['genre']) . '%' : '%';

            $sql = "SELECT * FROM books 
                    WHERE title LIKE '$title' 
                      AND author LIKE '$author' 
                      AND (isbn LIKE '$isbn' OR isbn IS NULL) 
                      AND (genre LIKE '$genre' OR genre IS NULL)";
            $res = $conn->query($sql);

            if ($res && $res->num_rows > 0):
        ?>
                <h3 class="mt-5">Результаты поиска</h3>
                <div class="row">
                <?php while ($book = $res->fetch_assoc()): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?= !empty($book['cover_url']) ? htmlspecialchars($book['cover_url']) : '/uploads/default-book.jpg' ?>" 
                                         class="img-fluid rounded-start h-100" style="object-fit: cover;" 
                                         alt="<?= htmlspecialchars($book['title']) ?>">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= htmlspecialchars($book['title']) ?></h5>
                                        <p class="card-text text-muted"><?= htmlspecialchars($book['author']) ?> (<?= $book['year'] ?>)</p>
                                        <?php if (!empty($book['isbn'])): ?>
                                            <p class="card-text"><small class="text-muted">ISBN: <?= htmlspecialchars($book['isbn']) ?></small></p>
                                        <?php endif; ?>
                                        <?php if (!empty($book['genre'])): ?>
                                            <p class="card-text"><small class="text-muted">Жанр: <?= htmlspecialchars($book['genre']) ?></small></p>
                                        <?php endif; ?>
                                        <?php if ($book['available'] > 0): ?>
                                            <a href="request_book.php?id=<?= $book['id']; ?>" class="btn btn-sm btn-primary">Запросить</a>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Нет в наличии</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                </div>
        <?php
            else:
                echo '<p class="mt-4 text-muted">Книг по вашему запросу не найдено.</p>';
            endif;
        endif;
        ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>